; MEM.COM - show the memory mapper segments of MSX-DOS2 (total / free / system / user per mapper) and the RAM disk.
; Reads the mapper variable table (EXTBIO D=4 E=1) and _RAMD (BDOS 68h, B=FFh).  Changes nothing.
; Build: sjasmplus --raw=MEM.COM mem.asm
        OUTPUT  "MEM.COM"
        ORG     0100h
BDOS    equ     0005h
HOKVLD  equ     0FB20h
EXTBIO  equ     0FFCAh

        ld      de,s_title
        call    prs
        ld      c,6Fh                   ; _DOSVER
        call    BDOS
        or      a
        jp      nz,e_dos
        ld      a,b
        cp      2
        jp      c,e_dos
        ld      a,(HOKVLD)
        rrca
        jp      nc,e_map
        xor     a
        ld      de,0401h                ; get mapper variable table
        call    EXTBIO
        or      a
        jp      z,e_map
        ld      (prim),a
        ld      (tab),hl
.next:  ld      hl,(tab)
        ld      a,(hl)                  ; slot, 0 = end of table
        or      a
        jr      z,.done
        ld      (cur),a
        ld      de,s_slot
        call    prs
        ld      a,(cur)
        and     3
        call    pdig
        ld      a,(cur)
        bit     7,a
        jr      z,.noexp
        ld      e,'-'
        call    pch
        ld      a,(cur)
        rrca
        rrca
        and     3
        call    pdig
.noexp: ld      a,(prim)
        ld      b,a
        ld      a,(cur)
        cp      b
        ld      de,s_prim
        call    z,prs
        ld      de,s_tot
        call    prs
        ld      hl,(tab)
        inc     hl
        ld      (ptr),hl
        call    pseg                    ; +1 total
        ld      de,s_free
        call    prs
        call    pseg                    ; +2 free
        ld      de,s_sys
        call    prs
        call    pseg                    ; +3 system
        ld      de,s_user
        call    prs
        call    pseg                    ; +4 user
        call    crlf
        ld      hl,(tab)
        ld      de,8
        add     hl,de
        ld      (tab),hl
        jr      .next
.done:  ld      b,0FFh                  ; _RAMD: get size
        ld      c,68h
        call    BDOS
        ld      (err),a
        ld      a,b
        ld      (cur),a
        ld      de,s_ramd
        call    prs
        ld      a,(err)
        or      a
        jr      nz,.rerr
        ld      a,(cur)
        or      a
        jr      z,.none
        ld      hl,cur
        ld      (ptr),hl
        call    pseg
        jr      .end
.rerr:  ld      de,s_rerr
        call    prs
        ld      a,(err)
        ld      l,a
        ld      h,0
        call    pdec
        ld      e,')'
        call    pch
        jr      .end
.none:  ld      de,s_none
        call    prs
.end:   jp      crlf

; print the segment count at (ptr) in decimal and its size in KB "n (nK)"; ptr+1 on return
pseg:   ld      hl,(ptr)
        ld      a,(hl)
        inc     hl
        ld      (ptr),hl
        push    af
        ld      l,a
        ld      h,0
        call    pdec
        ld      de,s_lp
        call    prs
        pop     af
        ld      l,a
        ld      h,0
        add     hl,hl
        add     hl,hl
        add     hl,hl
        add     hl,hl                   ; x16 KB
        call    pdec
        ld      de,s_k
        jp      prs

; print HL in decimal, no leading zeros
pdec:   ld      b,0                     ; digits printed
        ld      de,-1000
        call    .d
        ld      de,-100
        call    .d
        ld      de,-10
        call    .d
        ld      a,l
        jr      pdig
.d:     ld      a,-1
.l:     inc     a
        add     hl,de
        jr      c,.l
        sbc     hl,de
        or      a
        jr      nz,.p
        inc     b
        dec     b
        ret     z
.p:     inc     b
pdig:   push    hl
        push    bc
        add     a,'0'
        ld      e,a
        call    pch
        pop     bc
        pop     hl
        ret

crlf:   ld      de,s_crlf
prs:    ld      c,09h
        jp      BDOS
pch:    push    hl
        ld      c,02h
        call    BDOS
        pop     hl
        ret

e_dos:  ld      de,s_edos
        jp      prs
e_map:  ld      de,s_emap
        jp      prs

s_title: db     "MEM 1.0 - mapper (16K segs)",13,10,"$"
s_slot: db      "slot $"
s_tot:  db      13,10,"  total  $"
s_free: db      13,10,"  free   $"
s_sys:  db      13,10,"  system $"
s_user: db      13,10,"  user   $"
s_k:    db      "K)$"
s_prim: db      " (primary)$"
s_ramd: db      "RAM disk: $"
s_none: db      "none$"
s_rerr: db      "unknown (_RAMD error $"
s_lp:   db      " ($"
s_crlf: db      13,10,"$"
s_edos: db      "MSX-DOS 2 required",13,10,"$"
s_emap: db      "no mapper support routines",13,10,"$"
prim:   db      0
cur:    db      0
err:    db      0
tab:    dw      0
ptr:    dw      0
